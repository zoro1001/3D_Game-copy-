extends CharacterBody3D

@export var speed: float = 5.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.002

@onready var camera: Camera3D = $camera_mount/Camera3D
@onready var anim_player: AnimationPlayer = find_child("AnimationPlayer", true, false)
@onready var anim_tree: AnimationTree = find_child("AnimationTree", true, false)

var gravity: float = float(ProjectSettings.get_setting("physics/3d/default_gravity"))
var current_anim := ""

func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

	# 🔧 IMPORTANT: Keep AnimationTree OFF
	if anim_tree:
		anim_tree.active = false

	if anim_player == null:
		push_error("AnimationPlayer not found")


func _input(event):
	if event is InputEventMouseMotion:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera.rotate_x(-event.relative.y * mouse_sensitivity)
		camera.rotation.x = clamp(camera.rotation.x, deg_to_rad(-80), deg_to_rad(80))


func _physics_process(delta):
	if not is_on_floor():
		velocity.y -= gravity * delta

	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity
		_play_anim("get_up")

	var input_dir := Vector2(
		Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
		Input.get_action_strength("move_down") - Input.get_action_strength("move_up")
	)

	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

	move_and_slide()
	_update_animation()


func _update_animation():
	var move_speed := Vector3(velocity.x, 0, velocity.z).length()

	if not is_on_floor():
		return
	elif move_speed > 0.1:
		_play_anim("walking")
	else:
		_play_anim("idle")


func _play_anim(anim_name: String):
	if anim_player == null:
		return

	if current_anim == anim_name:
		return

	if anim_player.has_animation(anim_name):
		anim_player.play(anim_name)
		current_anim = anim_name
